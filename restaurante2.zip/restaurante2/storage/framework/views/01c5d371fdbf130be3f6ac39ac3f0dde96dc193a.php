<?php $__env->startSection('content'); ?>
<h2 class="titulo_boby"> Pedido</h2>
<br>
<?php if(Session::has('er')): ?>
	<div class="alert alert-danger alert-dismissible">
		 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<i class="fa fa-times" aria-hidden="true"></i>
			<?php echo session('er'); ?>

	</div>
<?php endif; ?>
<br>
<form action="<?php echo e(url('/inserir/pedido', $nr_conta)); ?>" method="post">
	<?php echo e(csrf_field()); ?>

	<table class="table table-striped tabela">			
		<thead>
			<tr>
			
			<th class="coluna_titulo">Quatidade</th>
				<th>
					Nome
				</th>
				<th>
					Preço
				</th>
				<th>
					Descrição
				</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($itens as $item): ?>
			<tr>
				<td>
					<input name="quant[<?php echo e($item->NR_ITEM); ?>]" type="number" min="1" class="form-control">
				</td>
				<td>
					<?php echo e($item->NOME); ?> 
				</td>
				<td>
					<?php echo e($item->PRECO); ?>

					<input name="valor[<?php echo e($item->NR_ITEM); ?>]" hidden="" value="<?php echo e($item->PRECO); ?>" type="text">
				</td>
				<td>
					<?php echo e($item->DESCRICAO); ?>

				</td>
				<th>	<button name="nr_item" value="<?php echo e($item->NR_ITEM); ?>" type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o fa-2x" aria-hidden="true"></i></button></th>
			</tr>
			<?php endforeach; ?>	
		</tbody>

	</table>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>