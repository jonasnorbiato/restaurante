<?php $__env->startSection('content'); ?>
<h2 class="titulo_boby"> Mesa <?php echo e($nr_mesa); ?> </h2>

	<div class="col-xs-12">
	  <?php if(Session::has('sucesso')): ?>
	    		<div class="alert alert-success alert-dismissible">
				 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		    			<i class="fa fa-check" aria-hidden="true"></i>
		    			<?php echo session('sucesso'); ?>


		    	</div>
			<?php endif; ?>
	</div>

<br>

<div class="col-xs-3 col-xs-offset-1">
	<form action="<?php echo e(url('/cadastrar/pedido', $conta[0]->NR_CONTA)); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		<button class="btn btn-default" type="submit"><h4>Efetuar Pedido</h4></button>
		
	</form>
</div>	

<div class="col-xs-3">
		<form action="<?php echo e(url('/fechar/conta', $conta[0]->NR_CONTA)); ?>" method="post">	
		<?php echo e(csrf_field()); ?>

		<button class="btn btn-default" type="submit"><h4>Fechar Venda</h4></button>
	</form>
	<br>
</div>


<div class="col-xs-3">
		<form action="<?php echo e(url('/cancelar/venda', $conta[0]->NR_CONTA)); ?>" method="get">	
	
		<button class="btn btn-default btn-apagar" type="submit"><h4>Cancelar Venda</h4></button>
	</form>
	<br>
</div>

<div class="xol-xs-12">

	<table class="table table-striped table-hover tabela">			
			<thead>
				<tr>
					<th class="titulo_teste">
						PRODUTO
					</th>
					<th>
						PREÇO
					</th>
					<th class="">
						QUANTIDADE
					</th>
					<th class="">
						PREÇO TOTAL
					</th>
					<th>
						
					</th>
				</tr>
			</thead>
			<tbody>
					<?php foreach($pedidos as $pedido): ?>
				<tr>
					<td>
						<?php echo e($pedido->itemcardapio->NOME); ?>

					</td>
					<td>
						<?php echo e($pedido->itemcardapio->PRECO); ?>

					</td>
					<td class="">
						<?php echo e($pedido->QUANTIDADE); ?>

					</td>
					<td>
						<?php echo e($pedido->PRECO_UNITARIO); ?>

					</td>
					<td>
						<a href="<?php echo e(url('/excluir/pedido', $pedido->NR_PEDIDO)); ?>" class="btn btn-danger btn-apagar"> <i class="fa fa-trash-o fa-2x" aria-hidden="true"></i></a>
					</td>
				</tr>
			<?php endforeach; ?>

			</tbody>
	</table>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>