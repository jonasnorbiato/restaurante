<?php $__env->startSection('content'); ?>
<h2 class="titulo_boby">Fechar Conta da Mesa <?php echo e($conta->NR_MESA); ?> </h2>
<br>
	<div class="col-xs-12">
	  <?php if(Session::has('sucesso')): ?>
	    		<div class="alert alert-success alert-dismissible">
				 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		    			<i class="fa fa-check" aria-hidden="true"></i>
		    			<?php echo session('sucesso'); ?>


		    	</div>
			<?php endif; ?>
	</div>

<br>
<div class="xol-xs-12">

	<table class="table table-striped table-hover tabela">			
			<thead>
				<tr>
					<th class="titulo_teste">
						PRODUTO
					</th>
					<th>
						PREÇO
					</th>
					<th class="">
						QUANTIDADE
					</th>
					<th class="">
						PREÇO TOTAL
					</th>
				</tr>
			</thead>
			<tbody>
					<?php foreach($pedidos as $pedido): ?>
				<tr>
					<td>
						<?php echo e($pedido->itemcardapio->NOME); ?>

					</td>
					<td>
						<?php echo e($pedido->itemcardapio->PRECO); ?>

					</td>
					<td class="">
						<?php echo e($pedido->QUANTIDADE); ?>

					</td>
					<td>
						<?php echo e($pedido->PRECO_UNITARIO); ?>

					</td>
				</tr>
			<?php endforeach; ?>
			<tr>
				<th> </th>
				<th ></th>
				<th ></th>
				<th >
					Total: <?php echo e($valor); ?>

				</th>
			</tr>
			
			</tbody>
	</table>
</div>	

<div class="col-xs-8 col-xs-offset-5">
	<a href="<?php echo e(url('/fechar/conta/salvar', $conta->NR_CONTA)); ?>" class="btn btn-primary"><h4>FECHAR</h4></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>