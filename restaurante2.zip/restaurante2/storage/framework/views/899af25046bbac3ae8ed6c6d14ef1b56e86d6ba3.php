<?php $__env->startSection('content'); ?>
	<h3 class="titulo_boby">Mesas</h3>
	<?php if(Session::has('sucesso')): ?>
    		<div class="alert alert-success alert-dismissible">
			 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	    			<i class="fa fa-check" aria-hidden="true"></i>
	    			<?php echo session('sucesso'); ?>


	    	</div>
		<?php endif; ?>
	<br>
	<?php foreach($mesas as $mesa): ?>
		<a href="<?php echo e(url('/realizar/pedido',$mesa->NR_MESA)); ?>" class="mesa"><img class="" src="<?php echo e(asset('img/mesa.png')); ?>" alt=""><?php echo e($mesa->NR_MESA); ?></a>
	<?php endforeach; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>