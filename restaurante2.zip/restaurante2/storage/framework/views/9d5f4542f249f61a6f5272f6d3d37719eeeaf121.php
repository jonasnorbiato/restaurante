<?php $__env->startSection('content'); ?>
<h2 class="titulo_boby">Abrir Conta na Mesa <?php echo e($nr_mesa); ?>



</h2>
<br>
<form action="<?php echo e(url('/inserir/conta')); ?>" method="POST">
	<?php echo e(csrf_field()); ?>

	<div class="col-xs-12">
		<label class="negrito" for="">Garçom:</label>
	</div>
	<input type="number" name="nr_mesa" value="<?php echo e($nr_mesa); ?>" hidden="">

		<div class="col-xs-12">
			<select name="garcon" id="" class="form-control" >
			<?php foreach($garcons as $garcon): ?>
					<option  value="<?php echo e($garcon->NR_GARCON); ?>"><?php echo e($garcon->NOME); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="col-xs-12">
		<br>
		<label for="" class="negrito">Pedido:</label>
 			<table class="table table-striped tabela">			
			<thead>
				<tr>
				
				<th class="coluna_titulo">Quatidade</th>
					<th>
						Nome
					</th>
					<th>
						Preço
					</th>
					<th>
						Descrição
					</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($itens as $item): ?>
				<tr>
					<td>
						<input name="quant[<?php echo e($item->NR_ITEM); ?>]" type="number" min="1" class="form-control">
					</td>
					<td>
						<?php echo e($item->NOME); ?> 
					</td>
					<td>
						<?php echo e($item->PRECO); ?>

						<input name="valor[<?php echo e($item->NR_ITEM); ?>]" hidden="" value="<?php echo e($item->PRECO); ?>" type="text">
					</td>
					<td>
						<?php echo e($item->DESCRICAO); ?>

					</td>
					<th>	<button name="nr_item" value="<?php echo e($item->NR_ITEM); ?>" type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o fa-2x" aria-hidden="true"></i></button></th>
				</tr>
				<?php endforeach; ?>	
			</tbody>

		</table>
</div>

</form>

<div class="col-xs-12">
		<br>	
	
		<?php if(count($errors)): ?>
			<div class="alert alert-danger alert-dismissible">
					 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>


    			<?php foreach($errors->all() as $erro): ?>
						<i class="fa fa-times" aria-hidden="true"></i>
						<?php echo e($erro); ?>

					<br>
    			<?php endforeach; ?>
			</div>
   		 <?php endif; ?>

   		 <?php if(Session::has('er')): ?>
    		<div class="alert alert-danger alert-dismissible">
				 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	    			<i class="fa fa-times" aria-hidden="true"></i>
	    			<?php echo session('er'); ?>


	    	</div>
		<?php endif; ?>
	</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>